DELETE FROM items;
DELETE FROM point_items;
DELETE FROM points;
